const jsonServer = require("json-server");
const server = jsonServer.create();
const router = jsonServer.router("data/db.json");
const middleware = jsonServer.defaults();

const cors = require("cors");

// Configure CORS with specific options
server.use(cors({
  origin: ['https://park-wheelz-xi.vercel.app', 'http://localhost:5173'],
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  credentials: true,
  optionsSuccessStatus: 204
}));

server.use(middleware);
server.use(jsonServer.bodyParser); // Enables JSON body parsing

// Custom route for debugging
server.post("/users", (req, res, next) => {
  console.log("Incoming Data:", req.body);
  next(); // Pass to json-server
});

// Add CORS headers for preflight requests
server.options('*', cors());

server.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', 'https://park-wheelz-xi.vercel.app');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.header('Access-Control-Allow-Credentials', 'true');
  next();
});

server.use(router);

server.listen(3000, () => {
  console.log("Server is Running at http://localhost:3000");
});
