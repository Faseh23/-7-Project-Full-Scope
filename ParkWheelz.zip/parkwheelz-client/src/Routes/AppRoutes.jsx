import { MapPin, Clock, CreditCard, Smartphone, Search } from "lucide-react";

const features = [
  {
    icon: <MapPin className="h-12 w-12 text-red-600" />, 
    title: "Real-time Availability", 
    description: "Find available parking spots in real-time with our interactive map."
  },
  {
    icon: <Clock className="h-12 w-12 text-red-600" />, 
    title: "Easy Reservations", 
    description: "Book your parking spot in advance and save time."
  },
  {
    icon: <CreditCard className="h-12 w-12 text-red-600" />, 
    title: "Secure Payments", 
    description: "Make hassle-free payments through our integrated payment gateway."
  },
  {
    icon: <Smartphone className="h-12 w-12 text-red-600" />, 
    title: "Mobile App", 
    description: "Manage your parking on-the-go with our user-friendly mobile app."
  }
];

const Features = () => {
  return (
    <section id="features" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12 text-gray-800">Our Features</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className="bg-white p-6 rounded-lg shadow-lg text-center hover:shadow-xl transition duration-300 transform hover:-translate-y-1"
            >
              <div className="flex justify-center mb-4">{feature.icon}</div>
              <h3 className="text-xl font-semibold mb-2 text-gray-800">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Hero = () => {
  return (
    <section id="home" className="bg-gradient-to-r from-red-600 to-red-700 text-white py-32 mt-16">
      <div className="container mx-auto px-4 text-center">
        <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
          Find Your Perfect Parking Spot <br className="hidden md:inline" />
          in Seconds
        </h1>
        <p className="text-xl mb-8 max-w-2xl mx-auto">
          ParkWheelz offers effortless parking solutions at your fingertips. Save time and reduce stress with our smart
          parking technology.
        </p>
        <div className="flex justify-center">
          <div className="relative w-full max-w-xl">
            <input
              type="text"
              placeholder="Enter location to find parking..."
              className="w-full py-4 px-6 rounded-full text-gray-800 focus:outline-none focus:ring-2 focus:ring-red-300 text-lg"
            />
            <button className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-red-500 text-white p-3 rounded-full hover:bg-red-400 transition duration-300">
              <Search className="h-6 w-6" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

const Home = () => {
  return (
    <>
      <Hero />
      <Features />
    </>
  );
};

export default Home;