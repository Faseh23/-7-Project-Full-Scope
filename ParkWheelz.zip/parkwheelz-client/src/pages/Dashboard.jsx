import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Header from "../components/Header";

export default function Dashboard() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({});
  const [loading, setLoading] = useState(true);
  const [isSidebarOpen, setSidebarOpen] = useState(false);

  useEffect(() => {
    const userId = localStorage.getItem("userId");
    if (!userId) {
      navigate("/login");
      return;
    }

    const fetchUserData = async () => {
      try {
        const response = await fetch(`${import.meta.env.VITE_API_BASE_URL}/users/${userId}`);
        if (!response.ok) throw new Error('Failed to fetch user data');
        const userData = await response.json();
        setUser(userData);
        setFormData(userData);
      } catch (error) {
        console.error("Error fetching user data:", error);
        localStorage.removeItem("userId");
        navigate("/login");
      } finally {
        setLoading(false);
      }
    };

    fetchUserData();
  }, [navigate]);

  const handleProfileUpdate = async () => {
    try {
      const response = await fetch(`${import.meta.env.VITE_API_BASE_URL}/users/${user.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData)
      });

      if (!response.ok) throw new Error('Failed to update profile');

      const updatedUser = await response.json();
      setUser(updatedUser);
      setFormData(updatedUser);
      setIsEditing(false);
      alert("Profile updated successfully!");
    } catch (error) {
      console.error("Error updating profile:", error);
      alert("Failed to update profile");
    }
  };

  const handleInputChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const toggleSidebar = () => {
    setSidebarOpen(!isSidebarOpen);
  };

  const logout = () => {
    localStorage.removeItem("userId");
    navigate("/login");
  };

  const HamburgerMenu = ({ toggleSidebar }) => (
    <button onClick={toggleSidebar} className="text-gray-600 hover:text-gray-900">
      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16" />
      </svg>
    </button>
  );

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100">
        <Header showAuthButtons={false} />
        <div className="flex justify-center items-center min-h-screen">
          <div className="text-xl font-semibold">Loading...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-gray-100">
      {/* Sidebar */}
      <div className={`fixed inset-y-0 left-0 w-64 bg-gray-900 text-white p-5 transform ${isSidebarOpen ? "translate-x-0" : "-translate-x-full"} transition-transform duration-300 z-20`}>
        <button onClick={toggleSidebar} className="text-xl font-bold">✖</button>
        <h2 className="text-lg font-semibold mt-4">Menu</h2>
        <ul className="mt-4 space-y-2">
          <li className="cursor-pointer hover:text-blue-400">🏠 Dashboard</li>
          <li className="cursor-pointer hover:text-blue-400">📍 Find Parking</li>
          <li className="cursor-pointer hover:text-blue-400">📅 My Reservations</li>
          <li className="cursor-pointer hover:text-blue-400">💳 Payments</li>
          <li className="cursor-pointer hover:text-blue-400">📊 Reports</li>
          <li className="cursor-pointer hover:text-green-400" onClick={() => setIsEditing(true)}>✏ Update Profile</li>
          <li className="cursor-pointer hover:text-red-500" onClick={logout}>🚪 Logout</li>
        </ul>
      </div>

      {/* Main Content */}
      <div className="flex-1">
        <div className="flex justify-between items-center bg-white shadow-md p-4">
          <HamburgerMenu toggleSidebar={toggleSidebar} />
          <h1 className="text-2xl font-bold">Welcome, {user?.name || "User"} 👋</h1>
          <button onClick={logout} className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600">Logout</button>
        </div>

        <main className="container mx-auto px-4 py-6">
          {isEditing ? (
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h2 className="text-xl font-semibold mb-4">Edit Profile</h2>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Name</label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name || ""}
                    onChange={handleInputChange}
                    className="mt-1 p-2 w-full border rounded-md"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Email</label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email || ""}
                    onChange={handleInputChange}
                    className="mt-1 p-2 w-full border rounded-md"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Phone</label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone || ""}
                    onChange={handleInputChange}
                    className="mt-1 p-2 w-full border rounded-md"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Vehicle Number</label>
                  <input
                    type="text"
                    name="vehicleNumber"
                    value={formData.vehicleNumber || ""}
                    onChange={handleInputChange}
                    className="mt-1 p-2 w-full border rounded-md"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Vehicle Type</label>
                  <select
                    name="vehicleType"
                    value={formData.vehicleType || ""}
                    onChange={handleInputChange}
                    className="mt-1 p-2 w-full border rounded-md"
                  >
                    <option value="">Select Vehicle Type</option>
                    <option value="car">Car</option>
                    <option value="bike">Bike</option>
                    <option value="truck">Truck</option>
                  </select>
                </div>
                <div className="flex justify-end space-x-4">
                  <button
                    onClick={() => {
                      setIsEditing(false);
                      setFormData(user);
                    }}
                    className="px-4 py-2 bg-gray-500 text-white rounded hover:bg-gray-600"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleProfileUpdate}
                    className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
                  >
                    Save Changes
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="bg-white shadow-md rounded-lg p-4">
                <h2 className="font-semibold mb-2">Find Parking</h2>
                <input type="text" placeholder="Search location..." className="w-full border px-3 py-2 rounded-md mb-2" />
                <button className="bg-blue-500 text-white px-4 py-2 rounded-md w-full">Search</button>
              </div>
              <div className="bg-white shadow-md rounded-lg p-4">
                <h2 className="font-semibold mb-2">My Reservations</h2>
                <p className="text-gray-600">No active reservations.</p>
              </div>
              <div className="bg-white shadow-md rounded-lg p-4">
                <h2 className="font-semibold mb-2">Payment History</h2>
                <p className="text-gray-600">No recent transactions.</p>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
