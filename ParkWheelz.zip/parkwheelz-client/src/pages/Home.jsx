import { Link } from "react-router-dom";

const Home = () => {
  return (
    <div className="text-center min-h-screen flex flex-col items-center justify-center bg-red-600 text-white p-10">
      <h1 className="text-4xl font-bold mb-4">Find Your Perfect Parking Spot in Seconds</h1>
      <p className="text-lg mb-6">
        ParkWheelz offers effortless parking solutions at your fingertips. Save time 
        and reduce stress with our smart parking technology.
      </p>
      <Link to="/register" className="bg-white text-red-600 px-6 py-3 rounded font-bold text-lg">
        Get Started
      </Link>
    </div>
  );
};

export default Home;
