import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

const Profile = () => {
  const [user, setUser] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const storedUser = localStorage.getItem("user");
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    } else {
      navigate("/login"); // Redirect if not logged in
    }
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem("user");
    navigate("/login"); // Redirect to login page
  };

  if (!user) return <p className="text-center mt-10 text-xl">Loading...</p>;

  return (
    <div className="flex justify-center items-center min-h-screen bg-gray-100">
      <div className="bg-white p-8 rounded-lg shadow-lg max-w-md w-full">
        <h2 className="text-2xl font-bold text-center text-gray-800 mb-6">Profile</h2>
        <p className="text-lg text-gray-700"><strong>Name:</strong> {user.name}</p>
        <p className="text-lg text-gray-700"><strong>Email:</strong> {user.email}</p>
        <button onClick={handleLogout} className="w-full mt-6 bg-red-600 text-white p-3 rounded hover:bg-red-700 transition">
          Logout
        </button>
      </div>
    </div>
  );
};

export default Profile;
