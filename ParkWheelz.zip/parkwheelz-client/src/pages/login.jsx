import { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function Login() {
  const navigate = useNavigate();
  const [credentials, setCredentials] = useState({ email: "", password: "" });
  const [isLoading, setIsLoading] = useState(false);

  const handleChange = (e) => {
    setCredentials({ ...credentials, [e.target.name]: e.target.value });
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      const response = await fetch(`${import.meta.env.VITE_API_BASE_URL}/users`);
      const users = await response.json();
      
      // Find user with matching email and password
      const user = users.find(u => u.email === credentials.email && u.password === credentials.password);

      if (user) {
        // Store the user ID in localStorage
        localStorage.setItem("userId", user.id);
        navigate("/dashboard");
      } else {
        alert("Invalid email or password");
      }
    } catch (error) {
      console.error('Login error:', error);
      alert("An error occurred during login");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex justify-center items-center min-h-screen bg-gray-900">
      <div className="bg-white p-6 rounded-lg shadow-lg w-96">
        <h2 className="text-2xl font-bold text-center mb-4 text-gray-800">Login</h2>
        <form onSubmit={handleLogin} className="space-y-4">
          <input 
            name="email" 
            type="email" 
            placeholder="Email" 
            className="w-full p-2 border border-gray-300 rounded" 
            onChange={handleChange} 
            required 
            disabled={isLoading}
          />
          <input 
            name="password" 
            type="password" 
            placeholder="Password" 
            className="w-full p-2 border border-gray-300 rounded" 
            onChange={handleChange} 
            required 
            disabled={isLoading}
          />
          <button 
            type="submit" 
            className={`w-full p-2 rounded text-white ${isLoading ? 'bg-blue-400 cursor-not-allowed' : 'bg-blue-500 hover:bg-blue-600'}`}
            disabled={isLoading}
          >
            {isLoading ? 'Logging in...' : 'Login'}
          </button>
        </form>
      </div>
    </div>
  );
}
