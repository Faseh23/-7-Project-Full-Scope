import { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function MultiStepRegistration() {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    phone: "",
    address: "",
    vehicleNumber: "",
    vehicleType: "",
    vehicleModel: "",
    role: "",
    paymentMethod: "",
    languages: [],
  });

  // Handle form input changes
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  // Handle language selection (multi-select)
  const handleLanguageChange = (e) => {
    const selectedLanguages = Array.from(e.target.selectedOptions, (opt) => opt.value);
    setFormData({ ...formData, languages: selectedLanguages });
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      console.log('API URL:', import.meta.env.VITE_API_BASE_URL); // Debug log
      const response = await fetch(import.meta.env.VITE_API_BASE_URL + '/users', {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        alert("Registration Successful!");
        navigate("/login");
      } else {
        const errorData = await response.json();
        alert(errorData.message || "Error in registration");
      }
    } catch (error) {
      console.error('Registration error:', error);
      alert("Error during registration. Please try again.");
    }
  };

  return (
    <div className="flex justify-center items-center min-h-screen bg-gray-900">
      <div className="bg-white p-6 rounded-lg shadow-lg w-96">
        <h2 className="text-2xl font-bold text-center mb-4 text-gray-800">Multi-Step Registration</h2>

        {/* Step 1: Personal Details */}
        {step === 1 && (
          <form className="space-y-4">
            <h3 className="text-xl font-semibold text-gray-700">Personal Details</h3>
            <input name="name" type="text" placeholder="Full Name" className="w-full p-2 border border-gray-300 rounded" onChange={handleChange} required />
            <input name="email" type="email" placeholder="Email" className="w-full p-2 border border-gray-300 rounded" onChange={handleChange} required />
            <input name="password" type="password" placeholder="Password" className="w-full p-2 border border-gray-300 rounded" onChange={handleChange} required />
            <input name="phone" type="text" placeholder="Phone Number" className="w-full p-2 border border-gray-300 rounded" onChange={handleChange} required />
            <input name="address" type="text" placeholder="Address" className="w-full p-2 border border-gray-300 rounded" onChange={handleChange} required />
            <button type="button" onClick={() => setStep(2)} className="w-full bg-blue-500 text-white p-2 rounded hover:bg-blue-600">Next</button>
          </form>
        )}

        {/* Step 2: Vehicle Details */}
        {step === 2 && (
          <form className="space-y-4">
            <h3 className="text-xl font-semibold text-gray-700">Vehicle Details</h3>
            <input name="vehicleNumber" type="text" placeholder="Vehicle Number" className="w-full p-2 border border-gray-300 rounded" onChange={handleChange} required />
            <select name="vehicleType" className="w-full p-2 border border-gray-300 rounded" onChange={handleChange} required>
              <option value="">Select Vehicle Type</option>
              <option value="car">Car</option>
              <option value="bike">Bike</option>
              <option value="truck">Truck</option>
            </select>
            <input name="vehicleModel" type="text" placeholder="Vehicle Model" className="w-full p-2 border border-gray-300 rounded" onChange={handleChange} required />
            <div className="flex justify-between">
              <button type="button" onClick={() => setStep(1)} className="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600">Back</button>
              <button type="button" onClick={() => setStep(3)} className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">Next</button>
            </div>
          </form>
        )}

        {/* Step 3: Other Details */}
        {step === 3 && (
          <form className="space-y-4">
            <h3 className="text-xl font-semibold text-gray-700">Other Details</h3>
            <select name="role" className="w-full p-2 border border-gray-300 rounded" onChange={handleChange} required>
              <option value="">Select Role</option>
              <option value="user">User</option>
              <option value="manager">Parking Lot Manager</option>
            </select>
            <select name="paymentMethod" className="w-full p-2 border border-gray-300 rounded" onChange={handleChange} required>
              <option value="">Select Payment Method</option>
              <option value="credit">Credit Card</option>
              <option value="upi">UPI</option>
              <option value="wallet">Wallet</option>
            </select>
            <select multiple name="languages" className="w-full p-2 border border-gray-300 rounded" onChange={handleLanguageChange} required>
              <option value="English">English</option>
              <option value="Hindi">Hindi</option>
              <option value="Telugu">Telugu</option>
              <option value="Tamil">Tamil</option>
            </select>
            <div className="flex justify-between">
              <button type="button" onClick={() => setStep(2)} className="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600">Back</button>
              <button type="submit" onClick={handleSubmit} className="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600">Submit</button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
