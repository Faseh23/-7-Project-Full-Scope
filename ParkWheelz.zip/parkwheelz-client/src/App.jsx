import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Home from "./pages/Home";
import Login from "./pages/login";
import Register from "./pages/Register";
import Footer from "./components/Footer";
import Dashboard from "./pages/Dashboard";
import Header from "./components/Header";

const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<><Header showAuthButtons={true} /><Home /></>} />
        <Route path="/login" element={<><Header showAuthButtons={true} /><Login /></>} />
        <Route path="/register" element={<><Header showAuthButtons={true} /><Register /></>} />
        <Route path="/dashboard" element={<Dashboard/>}/>
      </Routes>
      <Footer />
    </Router>
  );
};

export default App;
