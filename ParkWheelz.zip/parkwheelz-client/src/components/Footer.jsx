import { Facebook, Twitter, Instagram } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white py-10 mt-12">
      <div className="container mx-auto px-6 text-center">
        {/* Footer Title */}
        <h3 className="text-2xl font-semibold mb-4">Stay Connected with ParkWheelz</h3>

        {/* Footer Links */}
        <ul className="flex justify-center space-x-6 text-lg font-medium mb-6">
          <li><a href="/" className="hover:text-red-400 transition">Home</a></li>
          <li><a href="/login" className="hover:text-red-400 transition">Login</a></li>
          <li><a href="/register" className="hover:text-red-400 transition">Register</a></li>
        </ul>

        {/* Social Media Icons */}
        <div className="flex justify-center space-x-6">
          <a href="#" className="hover:text-red-400 transition"><Facebook size={24} /></a>
          <a href="#" className="hover:text-red-400 transition"><Twitter size={24} /></a>
          <a href="#" className="hover:text-red-400 transition"><Instagram size={24} /></a>
        </div>

        {/* Copyright */}
        <p className="text-sm text-gray-400 mt-6">© 2025 ParkWheelz. All rights reserved.</p>
      </div>
    </footer>
  );
};

export default Footer;
