import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../Context/AuthContext";
import HamburgerMenu from "./HamburgerMenu";

const Header = ({ showAuthButtons = false }) => {
  const navigate = useNavigate();
  const { isAuthenticated, setIsAuthenticated } = useAuth();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleLogout = () => {
    localStorage.removeItem("userId");
    setIsAuthenticated(false);
    navigate("/login");
  };

  return (
    <header className="bg-white shadow-md p-4">
      <div className="container mx-auto flex justify-between items-center">
        {/* Logo */}
        <Link to="/" className="text-red-600 text-2xl font-bold flex items-center">
          🚗 ParkWheelz
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex space-x-6 items-center">
          {showAuthButtons ? (
            <>
              <Link to="/" className="hover:text-red-600">Home</Link>
              <Link to="/features" className="hover:text-red-600">Features</Link>
              <Link to="/testimonials" className="hover:text-red-600">Testimonials</Link>
              <Link to="/contact" className="hover:text-red-600">Contact</Link>
              
              {!isAuthenticated && (
                <div className="flex items-center space-x-4">
                  <Link 
                    to="/login" 
                    className="border-2 border-red-600 text-red-600 px-4 py-2 rounded hover:bg-red-50 transition-colors"
                  >
                    Login
                  </Link>
                  <Link 
                    to="/register" 
                    className="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700 transition-colors"
                  >
                    Register
                  </Link>
                </div>
              )}
            </>
          ) : (
            <button 
              onClick={handleLogout} 
              className="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700 transition-colors"
            >
              Logout
            </button>
          )}
        </nav>

        {/* Mobile Menu Button */}
        <div className="md:hidden">
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="text-gray-600 hover:text-red-600"
          >
            <HamburgerMenu />
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden mt-4 py-2 border-t">
          <nav className="flex flex-col space-y-4">
            {showAuthButtons ? (
              <>
                <Link to="/" className="hover:text-red-600">Home</Link>
                <Link to="/features" className="hover:text-red-600">Features</Link>
                <Link to="/testimonials" className="hover:text-red-600">Testimonials</Link>
                <Link to="/contact" className="hover:text-red-600">Contact</Link>
                
                {!isAuthenticated && (
                  <div className="flex flex-col space-y-2">
                    <Link 
                      to="/login" 
                      className="border-2 border-red-600 text-red-600 px-4 py-2 rounded hover:bg-red-50 transition-colors text-center"
                    >
                      Login
                    </Link>
                    <Link 
                      to="/register" 
                      className="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700 transition-colors text-center"
                    >
                      Register
                    </Link>
                  </div>
                )}
              </>
            ) : (
              <button 
                onClick={handleLogout} 
                className="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700 transition-colors"
              >
                Logout
              </button>
            )}
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;
