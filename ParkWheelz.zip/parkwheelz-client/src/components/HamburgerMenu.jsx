export default function HamburgerMenu({ toggleSidebar }) {
    return (
      <button onClick={toggleSidebar} className="p-2 bg-gray-800 text-white rounded-lg">
        ☰
      </button>
    );
  }
  